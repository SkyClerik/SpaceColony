﻿using System;
using System.Collections.Generic;
using UnityEngine;

using LiteNetLib;
using LiteNetLib.Utils;

namespace OML
{
    //
    // This class is for building Dev/Release build that would upload logs to OML Console in Unity Editor
    //

    // How to use:
    //
    // 1. Create an empty game object and insert this Component to it on your application's starting scene.
    // 2. Config the IP Address and Port on Component's property list
    // 
    
    // NOTE: don't need to put this to every scene your have. Game Object with this class will stay even when scene change.

    public class OmlLogEmitter:  MonoBehaviour, ILogHandler, INetEventListener
    {
        static OmlLogEmitter mInstance = null;

        public enum NetConnState { Disconnected, Connecting, Connected }
        public enum EnableCondition { DevelopemntBuildOnly, Always }

        [Header("General Settings")]
        public EnableCondition runCondition = EnableCondition.DevelopemntBuildOnly;

        public bool includeStacktrace = true;
        public List<string> stackFilters= new List<string>();

        //public static bool state = ;

        ILogHandler mDefaultLogHandler = null;

        #region [ ========== Life-Cycle ========== ]
        
        void Start()
        {
            // NOTE: unless you want to test from Editor in ANOTHER project where OML is not present, don't remove this UNITY_EDITOR flag!
            //          otherwise, it won't work as they both will try to be log handler and one will be off eventually.

#if !UNITY_EDITOR
            if (mInstance == null)
            {
                mInstance = this;
                DontDestroyOnLoad(gameObject);

                name = "[OML_Log_Handler(Active)]";

                if (runCondition == EnableCondition.DevelopemntBuildOnly && !Debug.isDebugBuild)
                {
                    Debug.Log("remote logging NOT enabled.");
                    return;
                }
                Debug.Log("remote logging enabled.");

                mDefaultLogHandler = Debug.logger.logHandler;

                Application.logMessageReceived += OnLogMessageRecv;
                Debug.logger.logHandler = this;


                Connect();

            }
            else
            {
                name = "[OML_Log_Handler(Inactive)]";
            }
#endif
        }


        private void OnDestroy()
        {
            if (mDefaultLogHandler != null)
            {
                Debug.logger.logHandler = mDefaultLogHandler;
                Application.logMessageReceived -= OnLogMessageRecv;
            }
        }

        #endregion [ ========== Life-Cycle(End) ========== ]

        #region [ ========== Log Handling ========== ]


        public void LogFormat(LogType logType, UnityEngine.Object context, string format, params object[] args)
        {
            var msg = format;
            if (args.Length > 0)
            {
                msg = string.Format(format, args);
            }
            
            PushLog(logType, msg, GetStackTrace());

            //mDefaultLogHandler.LogFormat(logType, context, format, args);
        }

        public void OnLogMessageRecv(string message, string stackTrace, LogType type)
        {
            PushLog(type, message, stackTrace);
        }

        public void LogException(Exception exception, UnityEngine.Object context)
        {
            PushLog(LogType.Exception, exception.Message, exception.StackTrace);

            //mDefaultLogHandler.LogException(exception, context);
        }

        static readonly char[] LINE_DELIM = new char[] { '\n', '\r' };

        protected string GetStackTrace(int skipLines = 5)
        {
            if (skipLines <= 0)
                return Environment.StackTrace;

            var st = Environment.StackTrace;

            var lines = st.Split(LINE_DELIM, StringSplitOptions.RemoveEmptyEntries);

            int startIndex = skipLines;
            if (startIndex >= lines.Length)
                return "";

            var writer = new System.Text.StringBuilder();
            
            for( int i=startIndex; i<lines.Length; i++)
            {
                var skip = false;
                var tmp = lines[i].TrimStart();
                foreach ( var filter in stackFilters)
                {
                    if (tmp.StartsWith("at " + filter))
                    {
                        skip = true;
                        break;
                    }
                }

                if (!skip)
                    writer.AppendLine(lines[i]);
            }
            
            return writer.ToString();
        }

        #endregion [ ========== Log Handling (End) ========== ]


        public void PushLog(LogType t, string msg, string stack)
        {

            if (mPeer != null)
            {
                var writer = new NetDataWriter();
                writer.Put((int)t);
                writer.Put(msg);
                writer.Put(includeStacktrace);
                if (includeStacktrace)
                {
                    writer.Put(stack);
                }

                mPeer.Send(writer, SendOptions.ReliableOrdered);
            }

            //mDefaultLogHandler.LogFormat(LogType.Log, null, "Pushing Stacktace: {0}", stack);
        }


        #region [ ========== Network Stuff ========== ]
        
        [Header("Network Settings")]
        public int port = 5454;
        public string host = "127.0.0.1";

        string passKey = "OmlRemoteService";
        bool mStarted = false;
        bool mAutoReconnect = true;
        NetClient mClient;
        NetPeer mPeer;
        NetConnState mState = NetConnState.Disconnected;
        DateTime mNextReconnectAttempt = new DateTime();

        public void Connect()
        {
#if UNITY_EDITOR
            Debug.Log("[OML] connecting to " + host + ":" + port + " (" + passKey + ")");
#endif
            if (mClient == null)
            {
                mClient = new NetClient(this, passKey);
                mClient.UpdateTime = 15;
            }

            if (!mClient.IsConnected)
            {
                if (!mStarted)
                {
                    mClient.Start();
                    mStarted = true;
                }

                mClient.Connect(host, port);
            }
        }



        public void Update()
        {
            if (mDefaultLogHandler == null)
            {
                Destroy(gameObject);
                return;
            }

            if (mClient == null || !mStarted)
                return;

            try
            {
                mClient.PollEvents();

                if (!mClient.IsConnected && !mClient.IsRunning && mAutoReconnect)
                {
                    if (DateTime.Now > mNextReconnectAttempt)
                    {
                        mNextReconnectAttempt = DateTime.Now.AddSeconds(5);
                        Debug.LogWarning("[OML] re-connecting...");

                        Connect();
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning("[OML] Error: " + ex.Message + "\n" + ex.StackTrace);
            }
        }

        public void OnPeerConnected(NetPeer peer)
        {
            Debug.Log("[OML] Log sever connected. ID=" + peer.Id);

            mPeer = peer;
            mState = NetConnState.Connected;
        }

        public void OnPeerDisconnected(NetPeer peer, DisconnectReason disconnectReason, int socketErrorCode)
        {
            Debug.LogFormat("[OML] disconnected. Reason: {0}", disconnectReason);
            mPeer = null;
            mState = NetConnState.Disconnected;
            mStarted = false;
        }

        public void OnNetworkReceive(NetPeer peer, NetDataReader liteNetReader){}

        public void OnNetworkReceiveUnconnected(NetEndPoint remoteEndPoint, NetDataReader reader, UnconnectedMessageType messageType){}

        public void OnNetworkLatencyUpdate(NetPeer peer, int latency){}

        public void OnNetworkError(NetEndPoint endPoint, int socketErrorCode)
        {
            Debug.LogWarningFormat("[OML] error from {0} ErrCode: {1} ", endPoint, socketErrorCode);
        }

        #endregion [ ========== Network Stuff (End) ========== ]

    }

}

